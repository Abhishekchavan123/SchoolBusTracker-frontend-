import { useNavigate } from "react-router-dom";
export default function AddDriver() {
  const navigate = useNavigate();
  return (
    <div>
      <h1 className="text-4xl font-bold mb-8">Add Driver</h1>

      <div className="bg-white rounded-2xl shadow-lg border border-gray-200 p-8">

        <form className="grid grid-cols-1 md:grid-cols-2 gap-6">

          {/* Driver Information */}

          <div className="md:col-span-2">
            <h2 className="text-xl font-semibold text-blue-600 border-b pb-2">
              Driver Information
            </h2>
          </div>

          <div>
            <label className="block mb-2 font-medium text-gray-700">
              Driver Name
            </label>

            <input
              type="text"
              placeholder="Enter driver name"
              className="w-full rounded-xl border border-gray-300 bg-gray-50 p-3 outline-none transition focus:border-blue-500 focus:bg-white focus:ring-4 focus:ring-blue-100"
            />
          </div>

          <div>
            <label className="block mb-2 font-medium text-gray-700">
              Phone Number
            </label>

            <input
              type="tel"
              placeholder="Enter phone number"
              className="w-full rounded-xl border border-gray-300 bg-gray-50 p-3 outline-none transition focus:border-blue-500 focus:bg-white focus:ring-4 focus:ring-blue-100"
            />
          </div>

          <div>
            <label className="block mb-2 font-medium text-gray-700">
              Email
            </label>

            <input
              type="email"
              placeholder="Enter email address"
              className="w-full rounded-xl border border-gray-300 bg-gray-50 p-3 outline-none transition focus:border-blue-500 focus:bg-white focus:ring-4 focus:ring-blue-100"
            />
          </div>

          <div>
            <label className="block mb-2 font-medium text-gray-700">
              License Number
            </label>

            <input
              type="text"
              placeholder="Driving license number"
              className="w-full rounded-xl border border-gray-300 bg-gray-50 p-3 outline-none transition focus:border-blue-500 focus:bg-white focus:ring-4 focus:ring-blue-100"
            />
          </div>

          <div>
            <label className="block mb-2 font-medium text-gray-700">
              Bus Number
            </label>

            <input
              type="text"
              placeholder="Enter assigned bus number"
              className="w-full rounded-xl border border-gray-300 bg-gray-50 p-3 outline-none transition focus:border-blue-500 focus:bg-white focus:ring-4 focus:ring-blue-100"
            />
          </div>

          {/* Login Credentials */}

          <div className="md:col-span-2 mt-2">
            <h2 className="text-xl font-semibold text-red-600 border-b pb-2">
              Login Credentials
            </h2>
          </div>

          <div>
            <label className="block mb-2 font-medium text-gray-700">
              User ID
            </label>

            <input
              type="text"
              placeholder="Enter user ID"
              className="w-full rounded-xl border border-gray-300 bg-gray-50 p-3 outline-none transition focus:border-blue-500 focus:bg-white focus:ring-4 focus:ring-blue-100"
            />
          </div>

          <div>
            <label className="block mb-2 font-medium text-gray-700">
              Password
            </label>

            <input
              type="password"
              placeholder="Enter password"
              className="w-full rounded-xl border border-gray-300 bg-gray-50 p-3 outline-none transition focus:border-blue-500 focus:bg-white focus:ring-4 focus:ring-blue-100"
            />
          </div>

          <div>
            <label className="block mb-2 font-medium text-gray-700">
              Confirm Password
            </label>

            <input
              type="password"
              placeholder="Confirm password"
              className="w-full rounded-xl border border-gray-300 bg-gray-50 p-3 outline-none transition focus:border-blue-500 focus:bg-white focus:ring-4 focus:ring-blue-100"
            />
          </div>

          <div className="md:col-span-2 mt-4 gap-4 flex justify-end">
            <button
              className="bg-blue-600 hover:bg-blue-700 transition-all duration-300 text-white font-semibold px-8 py-3 rounded-xl shadow-md hover:shadow-lg"
            >
              Save Driver
            </button>
            <button onClick={() => navigate("/school/dashboard")}
              className="bg-red-600 hover:bg-red-700 transition-all duration-300 text-white font-semibold px-8 py-3 rounded-xl shadow-md hover:shadow-lg"
            >
              Cancle
            </button>
            </div>

        </form>

      </div>
    </div>
  );
}