import { useNavigate } from "react-router-dom";
export default function AddBus() {
  const navigate = useNavigate();
  return (
    <div>
      <h1 className="text-4xl font-bold mb-8">Add Bus</h1>

      <div className="bg-white rounded-2xl shadow-lg border border-gray-200 p-8">

        <form className="grid grid-cols-1 md:grid-cols-2 gap-6">

          {/* Bus Information */}

          <div className="md:col-span-2">
            <h2 className="text-xl font-semibold text-blue-600 border-b pb-2">
              Bus Information
            </h2>
          </div>

          <div>
            <label className="block mb-2 font-medium text-gray-700">
              Bus Number
            </label>

            <input
              type="text"
              placeholder="BUS-001"
              className="w-full rounded-xl border border-gray-300 bg-gray-50 p-3 outline-none transition focus:border-blue-500 focus:bg-white focus:ring-4 focus:ring-blue-100"
            />
          </div>

          <div>
            <label className="block mb-2 font-medium text-gray-700">
              Bus Name
            </label>

            <input
              type="text"
              placeholder="School Bus 1"
              className="w-full rounded-xl border border-gray-300 bg-gray-50 p-3 outline-none transition focus:border-blue-500 focus:bg-white focus:ring-4 focus:ring-blue-100"
            />
          </div>

          <div>
            <label className="block mb-2 font-medium text-gray-700">
              Vehicle Registration Number
            </label>

            <input
              type="text"
              placeholder="KA32AB1234"
              className="w-full rounded-xl border border-gray-300 bg-gray-50 p-3 outline-none transition focus:border-blue-500 focus:bg-white focus:ring-4 focus:ring-blue-100"
            />
          </div>

          <div>
            <label className="block mb-2 font-medium text-gray-700">
              Vehicle Model
            </label>

            <input
              type="text"
              placeholder="Ashok Leyland"
              className="w-full rounded-xl border border-gray-300 bg-gray-50 p-3 outline-none transition focus:border-blue-500 focus:bg-white focus:ring-4 focus:ring-blue-100"
            />
          </div>

          <div>
            <label className="block mb-2 font-medium text-gray-700">
              Bus Capacity
            </label>

            <input
              type="number"
              placeholder="50"
              className="w-full rounded-xl border border-gray-300 bg-gray-50 p-3 outline-none transition focus:border-blue-500 focus:bg-white focus:ring-4 focus:ring-blue-100"
            />
          </div>

          {/* Route Information */}

          <div className="md:col-span-2 mt-2">
            <h2 className="text-xl font-semibold text-green-600 border-b pb-2">
              Route Information
            </h2>
          </div>

          <div>
            <label className="block mb-2 font-medium text-gray-700">
              Route Number
            </label>

            <input
              type="text"
              placeholder="R-101"
              className="w-full rounded-xl border border-gray-300 bg-gray-50 p-3 outline-none transition focus:border-blue-500 focus:bg-white focus:ring-4 focus:ring-blue-100"
            />
          </div>

          <div>
            <label className="block mb-2 font-medium text-gray-700">
              Route Name
            </label>

            <input
              type="text"
              placeholder="City Center Route"
              className="w-full rounded-xl border border-gray-300 bg-gray-50 p-3 outline-none transition focus:border-blue-500 focus:bg-white focus:ring-4 focus:ring-blue-100"
            />
          </div>

          <div>
            <label className="block mb-2 font-medium text-gray-700">
              School Name
            </label>

            <select className="w-full rounded-xl border border-gray-300 bg-gray-50 p-3 outline-none focus:border-blue-500 focus:ring-4 focus:ring-blue-100">
              <option>Select School</option>
              <option>ABC Public School</option>
              <option>XYZ International School</option>
            </select>
          </div>

          <div>
            <label className="block mb-2 font-medium text-gray-700">
              Assigned Driver
            </label>

            <select className="w-full rounded-xl border border-gray-300 bg-gray-50 p-3 outline-none focus:border-blue-500 focus:ring-4 focus:ring-blue-100">
              <option>Select Driver</option>
              <option>Mahesh</option>
              <option>Ravi</option>
              <option>Suresh</option>
            </select>
          </div>

          {/* Tracking Information */}

          <div className="md:col-span-2 mt-2">
            <h2 className="text-xl font-semibold text-purple-600 border-b pb-2">
              Tracking Information
            </h2>
          </div>

          <div>
            <label className="block mb-2 font-medium text-gray-700">
              GPS Device ID
            </label>

            <input
              type="text"
              placeholder="GPS-001"
              className="w-full rounded-xl border border-gray-300 bg-gray-50 p-3 outline-none transition focus:border-blue-500 focus:bg-white focus:ring-4 focus:ring-blue-100"
            />
          </div>

          <div>
            <label className="block mb-2 font-medium text-gray-700">
              Bus Status
            </label>

            <select className="w-full rounded-xl border border-gray-300 bg-gray-50 p-3 outline-none focus:border-blue-500 focus:ring-4 focus:ring-blue-100">
              <option>Active</option>
              <option>Maintenance</option>
              <option>Inactive</option>
            </select>
          </div>


          <div className="md:col-span-2 mt-4 gap-4 flex justify-end">
            <button
              className="bg-blue-600 hover:bg-blue-700 transition-all duration-300 text-white font-semibold px-8 py-3 rounded-xl shadow-md hover:shadow-lg"
            >
              Save Bus
            </button>
            <button onClick={() => navigate("/school/dashboard")}
              className="bg-red-600 hover:bg-red-700 transition-all duration-300 text-white font-semibold px-8 py-3 rounded-xl shadow-md hover:shadow-lg"
            >
              Cancel
            </button>
          </div>

        </form>

      </div>
    </div>
  );
}