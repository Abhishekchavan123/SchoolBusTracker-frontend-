import { useNavigate } from "react-router-dom";
export default function AddStudent() {
  const navigate = useNavigate();
  return (
    <div>
      <h1 className="text-4xl font-bold mb-8">Add Student</h1>

      <div className="bg-white rounded-2xl shadow-lg border border-gray-200 p-8">

        <form className="grid grid-cols-1 md:grid-cols-2 gap-6">

          {/* Student Information */}

          <div className="md:col-span-2">
            <h2 className="text-xl font-semibold text-blue-600 border-b pb-2">
              Student Information
            </h2>
          </div>

          <div>
            <label className="block mb-2 font-medium text-gray-700">
              Student Name
            </label>

            <input
              type="text"
              placeholder="Enter student name"
              className="w-full rounded-xl border border-gray-300 bg-gray-50 p-3 outline-none transition focus:border-blue-500 focus:bg-white focus:ring-4 focus:ring-blue-100"
            />
          </div>

          <div>
            <label className="block mb-2 font-medium text-gray-700">
              Student ID
            </label>

            <input
              type="text"
              placeholder="Enter student ID"
              className="w-full rounded-xl border border-gray-300 bg-gray-50 p-3 outline-none transition focus:border-blue-500 focus:bg-white focus:ring-4 focus:ring-blue-100"
            />
          </div>

          <div>
            <label className="block mb-2 font-medium text-gray-700">
              School Name
            </label>

            <input
              type="text"
              placeholder="Enter school name"
              className="w-full rounded-xl border border-gray-300 bg-gray-50 p-3 outline-none transition focus:border-blue-500 focus:bg-white focus:ring-4 focus:ring-blue-100"
            />
          </div>

          {/* Parent Information */}

          <div className="md:col-span-2 mt-2">
            <h2 className="text-xl font-semibold text-green-600 border-b pb-2">
              Parent Information
            </h2>
          </div>

          <div>
            <label className="block mb-2 font-medium text-gray-700">
              Parent Name
            </label>

            <input
              type="text"
              placeholder="Enter parent name"
              className="w-full rounded-xl border border-gray-300 bg-gray-50 p-3 outline-none transition focus:border-blue-500 focus:bg-white focus:ring-4 focus:ring-blue-100"
            />
          </div>

          <div>
            <label className="block mb-2 font-medium text-gray-700">
              Parent Phone Number
            </label>

            <input
              type="tel"
              placeholder="Enter phone number"
              className="w-full rounded-xl border border-gray-300 bg-gray-50 p-3 outline-none transition focus:border-blue-500 focus:bg-white focus:ring-4 focus:ring-blue-100"
            />
          </div>

          <div>
            <label className="block mb-2 font-medium text-gray-700">
              Parent Email
            </label>

            <input
              type="email"
              placeholder="Enter parent email"
              className="w-full rounded-xl border border-gray-300 bg-gray-50 p-3 outline-none transition focus:border-blue-500 focus:bg-white focus:ring-4 focus:ring-blue-100"
            />
          </div>

          {/* Transport Information */}

          <div className="md:col-span-2 mt-2">
            <h2 className="text-xl font-semibold text-purple-600 border-b pb-2">
              Transport Information
            </h2>
          </div>

          <div>
            <label className="block mb-2 font-medium text-gray-700">
              Pickup Location
            </label>

            <input
              type="text"
              placeholder="Pickup location"
              className="w-full rounded-xl border border-gray-300 bg-gray-50 p-3 outline-none transition focus:border-blue-500 focus:bg-white focus:ring-4 focus:ring-blue-100"
            />
          </div>

          <div>
            <label className="block mb-2 font-medium text-gray-700">
              Assigned Driver
            </label>

            <select className="w-full rounded-xl border border-gray-300 bg-gray-50 p-3 outline-none focus:border-blue-500 focus:ring-4 focus:ring-blue-100">
              <option>Select Driver</option>
              <option>Driver 1</option>
              <option>Driver 2</option>
              <option>Driver 3</option>
            </select>
          </div>

          {/* Login Credentials */}

          <div className="md:col-span-2 mt-2">
            <h2 className="text-xl font-semibold text-red-600 border-b pb-2">
              Login Credentials
            </h2>
          </div>

          <div>
            <label className="block mb-2 font-medium text-gray-700">
              User ID
            </label>

            <input
              type="text"
              placeholder="Enter user ID"
              className="w-full rounded-xl border border-gray-300 bg-gray-50 p-3 outline-none transition focus:border-blue-500 focus:bg-white focus:ring-4 focus:ring-blue-100"
            />
          </div>

          <div>
            <label className="block mb-2 font-medium text-gray-700">
              Password
            </label>

            <input
              type="password"
              placeholder="Enter password"
              className="w-full rounded-xl border border-gray-300 bg-gray-50 p-3 outline-none transition focus:border-blue-500 focus:bg-white focus:ring-4 focus:ring-blue-100"
            />
          </div>

          <div>
            <label className="block mb-2 font-medium text-gray-700">
              Confirm Password
            </label>

            <input
              type="password"
              placeholder="Confirm password"
              className="w-full rounded-xl border border-gray-300 bg-gray-50 p-3 outline-none transition focus:border-blue-500 focus:bg-white focus:ring-4 focus:ring-blue-100"
            />
          </div>

          <div className="md:col-span-2 mt-4 gap-4 flex justify-end">
            <button
              className="bg-blue-600 hover:bg-blue-700 transition-all duration-300 text-white font-semibold px-8 py-3 rounded-xl shadow-md hover:shadow-lg"
            >
              Save Student
            </button>
            <button onClick={() => navigate("/school/dashboard")}
              className="bg-red-600 hover:bg-red-700 transition-all duration-300 text-white font-semibold px-8 py-3 rounded-xl shadow-md hover:shadow-lg"
            >
              Cancle
            </button>
          </div>

        </form>

      </div>
    </div>
  );
}