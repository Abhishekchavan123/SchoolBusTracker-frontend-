// src/components/About.jsx

export default function About() {
  return (
    <section
      id="about"
      className="relative min-h-screen bg-cover bg-center flex items-center justify-center px-6 py-20"
      style={{
        backgroundImage:
          "url(https://qsyyshbhsoqfaxoqdqwp.supabase.co/storage/v1/object/sign/assets/FD1.png?token=eyJraWQiOiJzdG9yYWdlLXVybC1zaWduaW5nLWtleV83NmNiMWMxMC1iZmFiLTQ0NzgtOWY4My00NmIyMDgxZWIyZmMiLCJhbGciOiJIUzI1NiJ9.eyJ1cmwiOiJhc3NldHMvRkQxLnBuZyIsImlhdCI6MTc1OTQ3NDI2MywiZXhwIjoxNzkxMDEwMjYzfQ.8uqLz6FP8bazzYLoITZPgSDfy1y_klWJC78gv47xHvY)",
      }}
    >
      <div className="absolute inset-0 bg-black/70"></div>

      <div className="relative max-w-4xl text-center">
        <h2 className="text-4xl font-bold text-yellow-400 mb-6">
          About Us
        </h2>

        <p className="text-lg md:text-xl leading-8 text-gray-200">
          DonateEasy is an innovative platform designed to bridge the gap
          between food donors and NGOs.

          <br /><br />

          <span className="text-yellow-400 font-semibold">
            Reduce food waste and feed the hungry.
          </span>

          <br /><br />

          Using smart technology we connect restaurants, hotels,
          events and individuals with NGOs and volunteers to ensure
          every meal reaches someone in need.

          <br /><br />

          Together we can create a world where no plate is wasted
          and nobody sleeps hungry.
        </p>
      </div>
    </section>
  );
}