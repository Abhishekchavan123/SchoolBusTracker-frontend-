// src/components/Hero.jsx

import { useEffect, useState } from "react";

const images = [
  "https://qsyyshbhsoqfaxoqdqwp.supabase.co/storage/v1/object/sign/assets/bg3.jpg?token=eyJraWQiOiJzdG9yYWdlLXVybC1zaWduaW5nLWtleV83NmNiMWMxMC1iZmFiLTQ0NzgtOWY4My00NmIyMDgxZWIyZmMiLCJhbGciOiJIUzI1NiJ9.eyJ1cmwiOiJhc3NldHMvYmczLmpwZyIsImlhdCI6MTc1OTQ3Mzk5MiwiZXhwIjoxNzkxMDA5OTkyfQ.s5oWyrDtgdcnlwFiS0_dLTMyTkeA_uV13sSdE_ZGIYI",

  "https://qsyyshbhsoqfaxoqdqwp.supabase.co/storage/v1/object/sign/assets/bg4.jpg?token=eyJraWQiOiJzdG9yYWdlLXVybC1zaWduaW5nLWtleV83NmNiMWMxMC1iZmFiLTQ0NzgtOWY4My00NmIyMDgxZWIyZmMiLCJhbGciOiJIUzI1NiJ9.eyJ1cmwiOiJhc3NldHMvYmc0LmpwZyIsImlhdCI6MTc1OTQ3Mzk5OSwiZXhwIjoxNzkxMDA5OTk5fQ.bIyYiFFbrs7lV238wnF6IVZvLgw7QbqkZAILBRwIAh0",

  "https://images.unsplash.com/photo-1504754524776-8f4f37790ca0?auto=format&fit=crop&w=1950&q=80",
];

export default function Hero() {
  const [current, setCurrent] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrent((prev) => (prev + 1) % images.length);
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  return (
    <section className="relative h-screen overflow-hidden">

      {/* Background Images */}

      {images.map((img, index) => (
        <div
          key={index}
          className={`absolute inset-0 bg-cover bg-center transition-opacity duration-1000 ${
            current === index ? "opacity-100" : "opacity-0"
          }`}
          style={{
            backgroundImage: `url(${img})`,
          }}
        />
      ))}

      {/* Dark Overlay */}

      <div className="absolute inset-0 bg-black/60"></div>

      {/* Hero Content */}

      <div className="relative z-10 flex h-[85vh] flex-col items-center justify-center px-6 text-center animate-fadeIn">

        <h1 className="mb-6 text-5xl font-extrabold leading-tight text-yellow-400 drop-shadow-lg md:text-6xl">
          Reduce Food Waste
          <br />
          Feed the Hungry
        </h1>

        <p className="mb-8 max-w-2xl text-lg text-gray-200 md:text-xl">
          Join our mission to connect surplus food from donors to those in
          need, making the world a better place — one meal at a time.
          <br />
          <br />
          <span className="italic">
            “Be the reason someone sleeps with a full stomach today.”
          </span>
        </p>

        <a href="/donate">
          <button className="rounded-lg bg-green-500 px-8 py-3 text-lg font-semibold text-white transition hover:bg-green-600 hover:scale-105">
            Donate Now
          </button>
        </a>

      </div>

      {/* Fade Animation */}

      <style>{`
        @keyframes fadeIn {
          from {
            opacity:0;
            transform:translateY(20px);
          }
          to{
            opacity:1;
            transform:translateY(0);
          }
        }

        .animate-fadeIn{
          animation:fadeIn 1s ease-in-out;
        }
      `}</style>

    </section>
  );
}